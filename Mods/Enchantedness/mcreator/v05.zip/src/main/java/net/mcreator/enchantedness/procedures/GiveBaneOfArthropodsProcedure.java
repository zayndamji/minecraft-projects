package net.mcreator.enchantedness.procedures;

import net.minecraft.item.ItemStack;
import net.minecraft.entity.Entity;

import net.mcreator.enchantedness.EnchantednessModElements;
import net.mcreator.enchantedness.EnchantednessMod;

import java.util.Map;

@EnchantednessModElements.ModElement.Tag
public class GiveBaneOfArthropodsProcedure extends EnchantednessModElements.ModElement {
	public GiveBaneOfArthropodsProcedure(EnchantednessModElements instance) {
		super(instance, 33);
	}

	public static void executeProcedure(Map<String, Object> dependencies) {
		if (dependencies.get("entity") == null) {
			if (!dependencies.containsKey("entity"))
				EnchantednessMod.LOGGER.warn("Failed to load dependency entity for procedure GiveBaneOfArthropods!");
			return;
		}
		if (dependencies.get("itemstack") == null) {
			if (!dependencies.containsKey("itemstack"))
				EnchantednessMod.LOGGER.warn("Failed to load dependency itemstack for procedure GiveBaneOfArthropods!");
			return;
		}
		Entity entity = (Entity) dependencies.get("entity");
		ItemStack itemstack = (ItemStack) dependencies.get("itemstack");
		((itemstack)).setCount((int) 0);
		{
			Entity _ent = entity;
			if (!_ent.world.isRemote && _ent.world.getServer() != null) {
				_ent.world.getServer().getCommandManager().handleCommand(_ent.getCommandSource().withFeedbackDisabled().withPermissionLevel(4),
						"give @s enchanted_book{StoredEnchantments:[{id:bane_of_arthropods,lvl:5}]} 1");
			}
		}
	}
}
