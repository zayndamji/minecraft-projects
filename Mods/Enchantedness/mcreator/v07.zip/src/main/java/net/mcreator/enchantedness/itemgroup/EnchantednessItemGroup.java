
package net.mcreator.enchantedness.itemgroup;

import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemGroup;

import net.mcreator.enchantedness.item.BlastProtectionBookItem;
import net.mcreator.enchantedness.EnchantednessModElements;

@EnchantednessModElements.ModElement.Tag
public class EnchantednessItemGroup extends EnchantednessModElements.ModElement {
	public EnchantednessItemGroup(EnchantednessModElements instance) {
		super(instance, 39);
	}

	@Override
	public void initElements() {
		tab = new ItemGroup("tabenchantedness") {
			@OnlyIn(Dist.CLIENT)
			@Override
			public ItemStack createIcon() {
				return new ItemStack(BlastProtectionBookItem.block, (int) (1));
			}

			@OnlyIn(Dist.CLIENT)
			public boolean hasSearchBar() {
				return false;
			}
		};
	}
	public static ItemGroup tab;
}
