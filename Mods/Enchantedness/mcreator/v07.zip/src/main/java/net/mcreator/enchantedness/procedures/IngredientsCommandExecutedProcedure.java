package net.mcreator.enchantedness.procedures;

import net.minecraft.util.ResourceLocation;
import net.minecraft.entity.Entity;
import net.minecraft.command.FunctionObject;

import net.mcreator.enchantedness.EnchantednessModElements;
import net.mcreator.enchantedness.EnchantednessMod;

import java.util.Optional;
import java.util.Map;
import java.util.HashMap;

@EnchantednessModElements.ModElement.Tag
public class IngredientsCommandExecutedProcedure extends EnchantednessModElements.ModElement {
	public IngredientsCommandExecutedProcedure(EnchantednessModElements instance) {
		super(instance, 23);
	}

	public static void executeProcedure(Map<String, Object> dependencies) {
		if (dependencies.get("entity") == null) {
			if (!dependencies.containsKey("entity"))
				EnchantednessMod.LOGGER.warn("Failed to load dependency entity for procedure IngredientsCommandExecuted!");
			return;
		}
		if (dependencies.get("cmdparams") == null) {
			if (!dependencies.containsKey("cmdparams"))
				EnchantednessMod.LOGGER.warn("Failed to load dependency cmdparams for procedure IngredientsCommandExecuted!");
			return;
		}
		Entity entity = (Entity) dependencies.get("entity");
		HashMap cmdparams = (HashMap) dependencies.get("cmdparams");
		if ((((new Object() {
			public String getText() {
				String param = (String) cmdparams.get("0");
				if (param != null) {
					return param;
				}
				return "";
			}
		}.getText())).equals("fortune"))) {
			if (!entity.world.isRemote && entity.world.getServer() != null) {
				Optional<FunctionObject> _fopt = entity.world.getServer().getFunctionManager()
						.get(new ResourceLocation("enchantedness:givefortunefunction"));
				if (_fopt.isPresent()) {
					FunctionObject _fobj = _fopt.get();
					entity.world.getServer().getFunctionManager().execute(_fobj, entity.getCommandSource());
				}
			}
		} else if ((((new Object() {
			public String getText() {
				String param = (String) cmdparams.get("0");
				if (param != null) {
					return param;
				}
				return "";
			}
		}.getText())).equals("unbreaking"))) {
			if (!entity.world.isRemote && entity.world.getServer() != null) {
				Optional<FunctionObject> _fopt = entity.world.getServer().getFunctionManager()
						.get(new ResourceLocation("enchantedness:giveunbreakingfunction"));
				if (_fopt.isPresent()) {
					FunctionObject _fobj = _fopt.get();
					entity.world.getServer().getFunctionManager().execute(_fobj, entity.getCommandSource());
				}
			}
		} else if ((((new Object() {
			public String getText() {
				String param = (String) cmdparams.get("0");
				if (param != null) {
					return param;
				}
				return "";
			}
		}.getText())).equals("efficiency"))) {
			if (!entity.world.isRemote && entity.world.getServer() != null) {
				Optional<FunctionObject> _fopt = entity.world.getServer().getFunctionManager()
						.get(new ResourceLocation("enchantedness:giveefficiencyfunction"));
				if (_fopt.isPresent()) {
					FunctionObject _fobj = _fopt.get();
					entity.world.getServer().getFunctionManager().execute(_fobj, entity.getCommandSource());
				}
			}
		} else if ((((new Object() {
			public String getText() {
				String param = (String) cmdparams.get("0");
				if (param != null) {
					return param;
				}
				return "";
			}
		}.getText())).equals("aqua_affinity"))) {
			if (!entity.world.isRemote && entity.world.getServer() != null) {
				Optional<FunctionObject> _fopt = entity.world.getServer().getFunctionManager()
						.get(new ResourceLocation("enchantedness:giveaquaaffinityfunction"));
				if (_fopt.isPresent()) {
					FunctionObject _fobj = _fopt.get();
					entity.world.getServer().getFunctionManager().execute(_fobj, entity.getCommandSource());
				}
			}
		} else if ((((new Object() {
			public String getText() {
				String param = (String) cmdparams.get("0");
				if (param != null) {
					return param;
				}
				return "";
			}
		}.getText())).equals("bane_of_arthropods"))) {
			if (!entity.world.isRemote && entity.world.getServer() != null) {
				Optional<FunctionObject> _fopt = entity.world.getServer().getFunctionManager()
						.get(new ResourceLocation("enchantedness:givebaneofarthropodsfunction"));
				if (_fopt.isPresent()) {
					FunctionObject _fobj = _fopt.get();
					entity.world.getServer().getFunctionManager().execute(_fobj, entity.getCommandSource());
				}
			}
		} else if ((((new Object() {
			public String getText() {
				String param = (String) cmdparams.get("0");
				if (param != null) {
					return param;
				}
				return "";
			}
		}.getText())).equals("blast_protection"))) {
			if (!entity.world.isRemote && entity.world.getServer() != null) {
				Optional<FunctionObject> _fopt = entity.world.getServer().getFunctionManager()
						.get(new ResourceLocation("enchantedness:giveblastprotectionfunction"));
				if (_fopt.isPresent()) {
					FunctionObject _fobj = _fopt.get();
					entity.world.getServer().getFunctionManager().execute(_fobj, entity.getCommandSource());
				}
			}
		} else if ((((new Object() {
			public String getText() {
				String param = (String) cmdparams.get("0");
				if (param != null) {
					return param;
				}
				return "";
			}
		}.getText())).equals("channeling"))) {
			if (!entity.world.isRemote && entity.world.getServer() != null) {
				Optional<FunctionObject> _fopt = entity.world.getServer().getFunctionManager()
						.get(new ResourceLocation("enchantedness:givechannelingfunction"));
				if (_fopt.isPresent()) {
					FunctionObject _fobj = _fopt.get();
					entity.world.getServer().getFunctionManager().execute(_fobj, entity.getCommandSource());
				}
			}
		} else if ((((new Object() {
			public String getText() {
				String param = (String) cmdparams.get("0");
				if (param != null) {
					return param;
				}
				return "";
			}
		}.getText())).equals("depth_strider"))) {
			if (!entity.world.isRemote && entity.world.getServer() != null) {
				Optional<FunctionObject> _fopt = entity.world.getServer().getFunctionManager()
						.get(new ResourceLocation("enchantedness:givedepthstriderfunction"));
				if (_fopt.isPresent()) {
					FunctionObject _fobj = _fopt.get();
					entity.world.getServer().getFunctionManager().execute(_fobj, entity.getCommandSource());
				}
			}
		} else if ((((new Object() {
			public String getText() {
				String param = (String) cmdparams.get("0");
				if (param != null) {
					return param;
				}
				return "";
			}
		}.getText())).equals("feather_falling"))) {
			if (!entity.world.isRemote && entity.world.getServer() != null) {
				Optional<FunctionObject> _fopt = entity.world.getServer().getFunctionManager()
						.get(new ResourceLocation("enchantedness:givefeatherfallingfunction"));
				if (_fopt.isPresent()) {
					FunctionObject _fobj = _fopt.get();
					entity.world.getServer().getFunctionManager().execute(_fobj, entity.getCommandSource());
				}
			}
		} else if ((((new Object() {
			public String getText() {
				String param = (String) cmdparams.get("0");
				if (param != null) {
					return param;
				}
				return "";
			}
		}.getText())).equals("all"))) {
			if (!entity.world.isRemote && entity.world.getServer() != null) {
				Optional<FunctionObject> _fopt = entity.world.getServer().getFunctionManager()
						.get(new ResourceLocation("enchantedness:giveaquaaffinityfunction"));
				if (_fopt.isPresent()) {
					FunctionObject _fobj = _fopt.get();
					entity.world.getServer().getFunctionManager().execute(_fobj, entity.getCommandSource());
				}
			}
			if (!entity.world.isRemote && entity.world.getServer() != null) {
				Optional<FunctionObject> _fopt = entity.world.getServer().getFunctionManager()
						.get(new ResourceLocation("enchantedness:giveefficiencyfunction"));
				if (_fopt.isPresent()) {
					FunctionObject _fobj = _fopt.get();
					entity.world.getServer().getFunctionManager().execute(_fobj, entity.getCommandSource());
				}
			}
			if (!entity.world.isRemote && entity.world.getServer() != null) {
				Optional<FunctionObject> _fopt = entity.world.getServer().getFunctionManager()
						.get(new ResourceLocation("enchantedness:giveunbreakingfunction"));
				if (_fopt.isPresent()) {
					FunctionObject _fobj = _fopt.get();
					entity.world.getServer().getFunctionManager().execute(_fobj, entity.getCommandSource());
				}
			}
			if (!entity.world.isRemote && entity.world.getServer() != null) {
				Optional<FunctionObject> _fopt = entity.world.getServer().getFunctionManager()
						.get(new ResourceLocation("enchantedness:givefortunefunction"));
				if (_fopt.isPresent()) {
					FunctionObject _fobj = _fopt.get();
					entity.world.getServer().getFunctionManager().execute(_fobj, entity.getCommandSource());
				}
			}
			if (!entity.world.isRemote && entity.world.getServer() != null) {
				Optional<FunctionObject> _fopt = entity.world.getServer().getFunctionManager()
						.get(new ResourceLocation("enchantedness:givebaneofarthropodsfunction"));
				if (_fopt.isPresent()) {
					FunctionObject _fobj = _fopt.get();
					entity.world.getServer().getFunctionManager().execute(_fobj, entity.getCommandSource());
				}
			}
			if (!entity.world.isRemote && entity.world.getServer() != null) {
				Optional<FunctionObject> _fopt = entity.world.getServer().getFunctionManager()
						.get(new ResourceLocation("enchantedness:giveblastprotectionfunction"));
				if (_fopt.isPresent()) {
					FunctionObject _fobj = _fopt.get();
					entity.world.getServer().getFunctionManager().execute(_fobj, entity.getCommandSource());
				}
			}
			if (!entity.world.isRemote && entity.world.getServer() != null) {
				Optional<FunctionObject> _fopt = entity.world.getServer().getFunctionManager()
						.get(new ResourceLocation("enchantedness:givechannelingfunction"));
				if (_fopt.isPresent()) {
					FunctionObject _fobj = _fopt.get();
					entity.world.getServer().getFunctionManager().execute(_fobj, entity.getCommandSource());
				}
			}
			if (!entity.world.isRemote && entity.world.getServer() != null) {
				Optional<FunctionObject> _fopt = entity.world.getServer().getFunctionManager()
						.get(new ResourceLocation("enchantedness:givedepthstriderfunction"));
				if (_fopt.isPresent()) {
					FunctionObject _fobj = _fopt.get();
					entity.world.getServer().getFunctionManager().execute(_fobj, entity.getCommandSource());
				}
			}
			if (!entity.world.isRemote && entity.world.getServer() != null) {
				Optional<FunctionObject> _fopt = entity.world.getServer().getFunctionManager()
						.get(new ResourceLocation("enchantedness:givefeatherfallingfunction"));
				if (_fopt.isPresent()) {
					FunctionObject _fobj = _fopt.get();
					entity.world.getServer().getFunctionManager().execute(_fobj, entity.getCommandSource());
				}
			}
		}
	}
}
